
package Google;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;

import java.util.Scanner;

 /*these imports work with the jousb library which is installed and
   added to this project*/

/**
 *
 * @author zainab
 */
public class Websearch {
    
    public static void main(String[] args) {}
    
    
    public static void search(){
        Scanner scanner = new Scanner(System.in);
        
                QuestionAnsweringSystem qaSystem = new QuestionAnsweringSystem();


                Scanner in = new Scanner(System.in);


                System.out.print("Enter your question: ");
                String question = in.nextLine();


                String answer = qaSystem.searchForAnswer(question);


                System.out.println("Answer: " + answer);
    }
    
  
}



class QuestionAnsweringSystem {
    private static final String SEARCH_API_URL = "https://www.google.com/search?q=";

    public String searchForAnswer(String question) {
        try {
            String answer = searchInURL(question);
            if (answer != null && !answer.isEmpty()) {
                return answer;
            }

            answer = searchInGoogle(question);
            if (answer != null && !answer.isEmpty()) {
                return answer;
            }

            return "Sorry, I couldn't find an answer to your question.";
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Sorry, an error occurred while searching for the answer.";
    }

    private String searchInURL(String question) throws IOException {
        URL url = new URL("https://intothegloss.com/");
        Document doc = Jsoup.parse(url, 3000);

        
        Elements contentElements = doc.getElementsContainingText(question);
        if (!contentElements.isEmpty()) {
            return contentElements.first().text();
        }

        return null;
    }

    private String searchInGoogle(String question) throws IOException {
        // Create the URL for the search query
        String encodedQuery = URLEncoder.encode(question, "UTF-8");
        URL url = new URL(SEARCH_API_URL + encodedQuery);


        Document doc = Jsoup.connect(url.toString()).get();


        Elements answerElements = doc.getElementsByClass("answer");
        if (!answerElements.isEmpty()) {
            return answerElements.first().text();
        }

        return null;
    }}
